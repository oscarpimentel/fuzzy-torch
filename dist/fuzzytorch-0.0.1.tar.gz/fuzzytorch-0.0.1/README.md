# fuzzy-torch

This is repository full of python functions, classes, methods, etc, that I've used along my adventure with Machine Learning, Data Science and programming in general.
This is based in pytorch

This is a personal and experimental library, so use it with caution.
If, for any reason, you are using this repo, then please report any bugs.

Autor: Óscar Pimentel Fuentes
Email: oscarlo.pimentel@gmail.com