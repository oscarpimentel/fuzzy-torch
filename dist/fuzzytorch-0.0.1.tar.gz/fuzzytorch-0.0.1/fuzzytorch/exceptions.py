from __future__ import print_function
from __future__ import division
from . import _C

###################################################################################################################################################

class NanLossError(Exception):
	def __init__(self):
		pass
		
class TrainingInterruptedError(Exception):
	def __init__(self):
		pass